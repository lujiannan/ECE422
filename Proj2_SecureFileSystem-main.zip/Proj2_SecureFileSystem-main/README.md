# Proj2_SecureFileSystem

## Deployment instructions

To deploy our SFS, you will just need to run it. The program will handle creating the necessary files if they do not already exist. To run our program, make sure you have all the python files in the same directory and have all the necessary libraries installed that are in the **requirements.txt**.

The file system should look like this before starting our program for the first time.

```
Named_Group_SFS/

|-- database.py

|-- encryption.py

|-- file_system_item.py

|-- integritycheck.py

|-- README.md

|-- requirements.txt

|-- SFS.py

|-- user.py
```

These instructions were tested on an Ubuntu 22.04 VM image

First run `sudo apt update` and then `sudo apt install python3-pip`

To install the required libraries, run `pip3 install -r requirements.txt`

After that, run our program for the first time, using `python3 SFS.py`

This will create the necessary files and the main Directory where our SFS Files will be saved. The file system would look like this after creating a User1 and 2 files under that directory. The actual names and contents inside SFS/ will be encrypted however.

```
Named_Group_SFS/

|-- database.py

|-- encryption.py

|-- file_system_item.py

|-- integritycheck.py

|-- README.md

|-- requirements.txt

|-- SFS/

| |-- {User1_Directory}/

| | |-- {text1.txt}

| | |-- {text2.txt}

|-- user.py

|-- user.db.txt

|-- groupdb.txt

|-- filesystemdb.txt
```

## User Guide

Please follow the steps above when first using our SFS. To begin with, an Admin account has been created for you to use, but you will not be able to create another one.

### Admin Account

The credentials for the admin account is

Username: **admin**

Password: **admin**

When signed in, you will see a Terminal like User Interface. Typing `Help` will allow you to see all the possible commands we are supporting and if needed, their arguments.

```
-------------------- WELCOME ---------------------



-------------------- SIGN IN ---------------------

Please enter your username: admin

Please enter your password: admin

~\SFS >> help



---------------------- HELP ----------------------

Commands:

pwd: Print the current working directory

ls: List the files and directories in the current directory. Use 'ls -l' to display detailed information, including file permissions, owner, and group.

cd <dir>: Change the current directory to the specified directory

mkdir <dir>: Create a new directory in the current directory

touch <file>: Create a new file in the current directory. Followup prompt will ask for the content

createuser <username>  <password>  <group>: Create a new user

currentUser: Print the current user

creategroup <groupname>: Create a new group

cat <file>: Print the contents of a file

echo <file>: Write to a file

mv <old_filename>  <new_name>: Rename a file

rm <file>: Remove a file

chmod <file>  <permissions>: Change permissions of filesystem item

logout: Logout of the current user

exit: Exit the SFS
```

As an admin, `createuser` and `creategroup` would be the most important commands.

`Createuser` will create a user, given a username, password and group name. If the group does exist, the user will be added under it, but if it does not, it will create it, meaning `creategroup` command is not needed.

`~\SFS >> createuser User1 Password Group1`

After creating a user, a directory would be created just for this user. Now, as an admin, you can either exit the program, or logout, and then sign into the new user you created.

### User Account

Once signed in, it will perform an **integrity check**, to make sure the files for the user have not changed. This is done in the background, and unless something was changed, you will not see the status.

Once you are signed in and have changed into your own directory, you can start playing around with the commands seen in `help`. You will not be able to create files inside the **SFS** directory itself( only an **Admin** can), or in other directories you don't have access to. Also for the commands that have an argument `<file>`, you will need the **decrypted** file name not the encrypted one. To find the decrypted file name, just run `ls`. If you have permission for that file, you will see the decrypted name. If not, even if you run that command, you will not have access to that file.

from typing import List
import bcrypt  # hash password


class User:
    """
    Represents a user in the system.
    Attributes:
        __name (str): The name of the user.
        __password (str): The password of the user.
        __group (str): The group of the user.
    """

    def __init__(self, name: str, password: str, group: str) -> None:
        """
        Initialize a User object.
        Args:
            name (str): The name of the user.
            password (str): The password of the user.
            group (str): The group of the user.
        Returns:
            None
        """
        self.__name: str = name
        if self.is_bcrypt_hash(password):
            self.__password: str = password
        else:
            self.__password: str = self.hash_pwd(password)
        self.__group: str = group

    def hash_pwd(self, password: str) -> str:
        """
        Hashes the given password using bcrypt and returns the hashed password.
        Parameters:
        - password (str): The password to be hashed.
        Returns:
        - str: The hashed password.
        """
        from file_system_item import SALT

        # Generate a salt and hash the password
        hashed_password = bcrypt.hashpw(password.encode("utf-8"), SALT)
        return hashed_password.decode("utf-8")

    def get_name(self) -> str:
        """
        Returns the name of the user.
        Returns:
            str: The name of the user.
        """
        return self.__name

    def get_password(self) -> str:
        """
        Returns the password of the user.
        Returns:
            str: The password of the user.
        """
        return self.__password

    def get_group_name(self) -> str:
        """
        Returns the group name associated with the user.
        Returns:
            str: The group name.
        """
        return self.__group

    def is_bcrypt_hash(self, s: str) -> bool:
        """
        Check if a string is a valid bcrypt hash.
        Args:
            s (str): The string to check.
        Returns:
            bool: True if the string is a valid bcrypt hash, False otherwise.
        """
        return len(s) == 60 and s[:4] in {"$2a$", "$2b$", "$2x$", "$2y$"}

    def get_database_str(self):
        """
        Returns a string representation of the user's database information. The returned string includes the user's name, password, and group.
        Returns:
            str: A string representation of the user's database information.
        """
        return f"{self.__name},{self.__password},{self.__group}"


class Group:
    """
    Represents a group of users.
    Attributes:
        __group_name (str): The name of the group.
        __members (List[str]): The list of members in the group.
    """

    def __init__(self, group_name: str, group_members=None) -> None:
        """
        Initializes a new instance of the Group class.
        Args:
            group_name (str): The name of the group.
            group_members (List[str], optional): The initial list of group members. Defaults to an empty list.
        """
        self.__group_name: str = group_name
        if group_members is None:
            group_members = []

        self.__members: List[str] = group_members

    def add_member(self, user_name: str):
        """
        Adds a member to the group.
        Args:
            user_name (str): The name of the user to add.
        """
        if isinstance(user_name, str):
            self.__members.append(user_name)
        else:
            print("Error adding user name to group: invalid user name")

    def remove_member(self, user_name: str):
        """
        Removes a member from the group.
        Args:
            user_name (str): The name of the user to remove.
        """
        if user_name in self.__members:
            self.__members.remove(user_name)
        else:
            print("Error removing user name from group: user name not found")

    def print_members(self):
        """
        Prints the members of the group.
        """
        print("Group Members:\n")
        for member_name in self.__members:
            print(f"Name: {member_name}")

    def get_group_name(self) -> str:
        """
        Returns the name of the group.
        Returns:
            str: The name of the group.
        """
        return self.__group_name

    def get_members(self) -> List[str]:
        """
        Returns the list of members in the group.
        Returns:
            List[str]: The list of members in the group.
        """
        return self.__members

    def get_database_str(self):
        """
        Returns a string representation of the group for database storage.
        Returns:
            str: The string representation of the group.
        """
        list_of_members = ",".join(self.__members)
        return f"{self.__group_name},{list_of_members}"


class Admin(User):
    """
    Represents an administrative user. Inherits from the User class and provides additional methods for creating groups and users.
    Attributes:
        None
    Methods:
        __init__(self): Initializes an Admin object.
        create_group(self, group_name: str) -> Group: Creates a new group with the given name.
        create_user(self, name: str, password: str, group_name: str) -> User: Creates a new user with the given name, password, and group name.
    """

    def __init__(self) -> None:
        group = self.create_group("admin")
        name = "admin"
        password = "admin"
        super().__init__(name, password, group.get_group_name())

    def create_group(self, group_name: str) -> Group:
        """
        Creates a new group with the given name. If the group already exists, retrieves the existing group.
        Args:
            group_name (str): The name of the group.
        Returns:
            Group: The created or retrieved group object.
        """
        from database import (
            store_group,
            get_group,
        )

        group = get_group(group_name)
        if group is None:
            group = Group(group_name)
            store_group(group)
        return group

    def create_user(self, name: str, password: str, group_name: str) -> User:
        """
        Creates a new user with the given name, password, and group name. If the group does not exist, creates a new group with the given group name.
        Args:
            name (str): The name of the user.
            password (str): The password of the user.
            group_name (str): The name of the group the user belongs to.
        Returns:
            User: The created user object.
        """
        from database import get_group, add_group_member, store_user

        group = get_group(group_name) or self.create_group(group_name)
        add_group_member(group_name, name)

        user = User(name, password, group.get_group_name())

        store_user(user)
        print(f"User {name} has been created successfully")
        return user

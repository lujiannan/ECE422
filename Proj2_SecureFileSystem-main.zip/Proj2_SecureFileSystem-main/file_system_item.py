from typing import List
from dataclasses import dataclass
import bcrypt


SALT = b"$2b$12$secretsaltsecretsaltse"  # Fixed salt for hashing passwords and file content


def convert_hash(prehash: str):
    return bcrypt.hashpw(prehash.encode(), SALT).decode("utf-8")


@dataclass
class Permission:
    """
    Represents the permissions of a file or directory.
    Attributes:
        r (bool): Indicates whether the file or directory has read permission.
        w (bool): Indicates whether the file or directory has write permission.
    """

    r: bool = False
    w: bool = False

    def __init__(self, perm: str):
        """
        Initializes a Permission object.
        Args:
            perm (str): A string representing the permissions. It should be a 2-character string
                        consisting of 'r' and/or 'w' to indicate read and write permissions respectively.
        Raises:
            AssertionError: If the length of the perm string is not 2.
        """
        assert len(perm) == 2
        self.r = "r" in perm
        self.w = "w" in perm

    def __str__(self) -> str:
        """
        Returns a string representation of the permissions.
        Returns:
            str: A string representing the permissions. It consists of 'r' and/or 'w' characters
                 indicating read and write permissions respectively.
        """
        return ("r" if self.r else "-") + ("w" if self.w else "-")

    def set_permissions(self, perm: str):
        """
        Sets the permissions.
        Args:
            perm (str): A string representing the permissions. It should be a 2-character string
                        consisting of 'r' and/or 'w' to indicate read and write permissions respectively.
        Raises:
            AssertionError: If the length of the perm string is not 2.
        """
        assert len(perm) == 2
        self.r = "r" in perm
        self.w = "w" in perm


@dataclass
class FS_ItemMode:
    """
    Represents the file system item mode, which includes permissions for the user, group, and others.
    """

    user: Permission
    group: Permission
    other: Permission

    def __init__(self, mode: str):
        """
        Initializes the FS_ItemMode object.
        Args:
            mode (str): The mode string in the form "rwr---w".
        """
        assert len(mode) == 6
        self.user = Permission(mode[0:2])
        self.group = Permission(mode[2:4])
        self.other = Permission(mode[4:6])

    def __str__(self) -> str:
        """
        Returns a string representation of the FS_ItemMode object.
        Returns:
            str: The string representation of the FS_ItemMode object.
        """
        return str(self.user) + str(self.group) + str(self.other)

    def set_permissions(self, mode: str):
        """
        Sets the permissions for the FS_ItemMode object.
        Args:
            mode (str): The mode string in the form "rwr---w".
        """
        assert len(mode) == 6
        self.user.set_permissions(mode[0:2])
        self.group.set_permissions(mode[2:4])
        self.other.set_permissions(mode[4:6])


class File:
    pass


class Directory:
    pass


# class declaration
class FileSystemItem:
    """
    Represents a file system item with its name, owner, group, and permissions.
    """

    def __init__(
        self, name: str, owner: str, group: str, permission: FS_ItemMode
    ) -> None:
        """
        Initializes a new instance of the FileSystemItem class.
        Args:
            name (str): The name of the file system item.
            owner (str): The owner of the file system item.
            group (str): The group of the file system item.
            permission (FS_ItemMode): The permission mode of the file system item.
        """
        self.__name: str = name
        self.__owner: str = owner
        self.__group: str = group
        self.__permission: FS_ItemMode = permission

    def set_permissions(self, permission: str):
        """
        Sets the permissions of the file system item.
        Args:
            permission (str): The permission string to set.
        """
        self.__permission = FS_ItemMode(permission)

    def set_name(self, name: str):
        """
        Sets the name of the file system item.
        Args:
            name (str): The name to set.
        """
        self.__name = name

    def get_permissions(self) -> FS_ItemMode:
        """
        Gets the permissions of the file system item.
        Returns:
            FS_ItemMode: The permission mode of the file system item.
        """
        return self.__permission

    def get_owner(self) -> str:
        """
        Gets the owner of the file system item.
        Returns:
            str: The owner of the file system item.
        """
        return self.__owner

    def get_group(self) -> str:
        """
        Gets the group of the file system item.
        Returns:
            str: The group of the file system item.
        """
        return self.__group

    def get_name(self) -> str:
        """
        Gets the name of the file system item.
        Returns:
            str: The name of the file system item.
        """
        return self.__name

    def get_perm(self) -> FS_ItemMode:
        """
        Gets the permissions of the file system item.
        Returns:
            FS_ItemMode: The permission mode of the file system item.
        """
        return self.__permission

    def get_access(self, accessor: str, action: str):
        """
        Gets the access permission for the specified accessor and action.
        Args:
            accessor (str): The accessor type ("user", "group", or "other").
            action (str): The action type ("r" for read or "w" for write).
        Returns:
            bool: True if the accessor has permission for the action, False otherwise.
        """
        access_map = {
            "user": {"r": self.__permission.user.r, "w": self.__permission.user.w},
            "group": {"r": self.__permission.group.r, "w": self.__permission.group.w},
            "other": {"r": self.__permission.other.r, "w": self.__permission.other.w},
        }
        return access_map[accessor][action]


class Directory(FileSystemItem):
    """
    Represents a directory in a file system.
    Attributes:
        name (str): The name of the directory.
        owner (str): The owner of the directory.
        group (str): The group of the directory.
        contents (List[FileSystemItem], optional): The contents of the directory. Defaults to None.
        permission (FS_ItemMode, optional): The permission mode of the directory. Defaults to None.
    """

    def __init__(
        self,
        name: str,
        owner: str,
        group: str,
        contents: List[FileSystemItem] | None = None,
        permission: FS_ItemMode | None = None,
    ) -> None:
        """
        Initializes a new instance of the Directory class.
        Args:
            name (str): The name of the directory.
            owner (str): The owner of the directory.
            group (str): The group of the directory.
            contents (List[FileSystemItem], optional): The contents of the directory. Defaults to None.
            permission (FS_ItemMode, optional): The permission mode of the directory. Defaults to None.
        """
        if permission is None:
            permission = FS_ItemMode("rwr---")
        super().__init__(name, owner, group, permission)
        if contents is None:
            contents = []
        self.__contents: List[FileSystemItem] = contents

    def create_file(self, file: File):
        """
        Creates a new file in the directory.
        Args:
            file (File): The file to be created.
        """
        self.__contents.append(file)

    def create_dir(self, directory: Directory):
        """
        Creates a new directory in the directory.
        Args:
            directory (Directory): The directory to be created.
        """
        self.__contents.append(directory)

    def add_content(self, item: FileSystemItem):
        """
        Adds a file or directory to the directory.
        Args:
            item (FileSystemItem): The file or directory to be added.
        """
        self.__contents.append(item)

    def set_contents(self, contents: List[FileSystemItem]):
        """
        Sets the contents of the directory.
        Args:
            contents (List[FileSystemItem]): The new contents of the directory.
        """
        self.__contents = contents

    def delete(self, name: str):
        """
        Deletes a file or directory from the directory.
        Args:
            name (str): The name of the file or directory to be deleted.
        """
        obj = self.find_item_by_name(name)
        if obj is None:
            print("\nError deleting FileSystemItem: item not exist")
        else:
            self.__contents.remove(obj)

    def find_item_by_name(self, name: str) -> FileSystemItem:
        """
        Finds a file or directory in the directory by its name.
        Args:
            name (str): The name of the file or directory to be found.
        Returns:
            FileSystemItem: The found file or directory, or None if not found.
        """
        for obj in self.__contents:
            if obj.__name == name:
                return obj
        return None

    def get_contents(self) -> List[FileSystemItem]:
        """
        Returns the contents of the directory.
        Returns:
            List[FileSystemItem]: The contents of the directory.
        """
        return self.__contents

    def get_hash(self):
        """
        Calculates the hash value of the directory.
        Returns:
            str: The hash value of the directory.
        """
        pre_hash = self.get_name()
        if self.__contents:
            sorted_contents = sorted(self.__contents, key=lambda x: x.get_name())
            for item in sorted_contents:
                pre_hash += item.get_hash()  # Include item hash
        return convert_hash(pre_hash)

    def get_database_str(self):
        """
        Returns a string representation of the directory for database storage.
        Returns:
            str: The string representation of the directory.
        """
        return (
            "d,"
            + self.get_name()
            + ","
            + self.get_owner()
            + ","
            + self.get_group()
            + ","
            + self.get_hash()
            + ","
            + str(self.get_permissions())
        )


class File(FileSystemItem):
    """
    Represents a file in a file system.
    Args:
        name (str): The name of the file.
        owner (str): The owner of the file.
        group (str): The group of the file.
        content (str, optional): The content of the file. Defaults to an empty string.
        permission (FS_ItemMode | None, optional): The permission mode of the file. Defaults to None.
    Attributes:
        content (str): The content of the file.
    Methods:
        add_content(content: str) -> None: Adds content to the file.
        get_hash() -> str: Returns the hash value of the file.
        get_database_str() -> str: Returns a string representation of the file for database storage.
    """

    def __init__(
        self,
        name: str,
        owner: str,
        group: str,
        content: str = "",
        permission: FS_ItemMode | None = None,
    ) -> None:
        """
        Initializes a new instance of the FileSystemItem class.
        Args:
            name (str): The name of the file system item.
            owner (str): The owner of the file system item.
            group (str): The group of the file system item.
            content (str, optional): The content of the file system item. Defaults to an empty string.
            permission (FS_ItemMode | None, optional): The permission of the file system item. Defaults to None.
        Returns:
            None
        """
        if permission is None:
            permission = FS_ItemMode("rw----")
        super().__init__(name, owner, group, permission)
        self.content = content

    def add_content(self, content: str):
        """Adds content to the file.
        Args:
            content (str): The content to be added.
        """
        self.content = content

    def get_hash(self):
        """Returns the hash value of the file.
        Returns:
            str: The hash value of the file.
        """
        hash = self.get_name() + self.content
        return convert_hash(hash)

    def get_database_str(self):
        """Returns a string representation of the file for database storage.
        Returns:
            str: The string representation of the file.
        """
        return (
            "f,"
            + self.get_name()
            + ","
            + self.get_owner()
            + ","
            + self.get_group()
            + ","
            + self.get_hash()
            + ","
            + str(self.get_permissions())
        )

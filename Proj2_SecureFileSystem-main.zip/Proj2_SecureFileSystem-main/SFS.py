import os  # for os operations
from user import User, Admin
from encryption import encrypt, decrypt  # for encryption and decryption
from database import (
    get_filesystem_item,
    get_user,
    load_database,
    verify_password,
    store_filesystem,
    store_files,
    store_database,
    MAIN_DIRECTORY,
    users,
    fs_items,
)

import re
import os  # for os operations
from file_system_item import (
    Directory,
    File,
    FileSystemItem,
)  # for file system items
from integritycheck import integrity_check  # for integrity check


"""
Shared section for client and server(SFS)
"""
# global fields
current_user: User = None
# Real world absolute path of current directory without trailing slash
abs_current_dir: str = os.path.join(
    MAIN_DIRECTORY, "SFS"
)  # Initialize the current directory to the main directory


def print_help():
    """
    Prints the help menu with a list of available commands.
    """
    print_division("HELP")
    print(
        "Commands:\n"
        "pwd: Print the current working directory\n"
        "ls: List the files and directories in the current directory. Use 'ls -l' to display detailed information, including file permissions, owner, and group.\n"
        "cd <dir>: Change the current directory to the specified directory\n"
        "mkdir <dir>: Create a new directory in the current directory\n"
        "touch <file>: Create a new file in the current directory. Followup prompt will ask for the content\n"
        "createuser <username> <password> <group>: Create a new user\n"
        "currentUser: Print the current user\n"
        "creategroup <groupname>: Create a new group\n"
        "cat <file>: Print the contents of a file\n"
        "echo <file>: Write to a file\n"
        "mv <old_filename> <new_name>: Rename a file\n"
        "rm <file>: Remove a file\n"
        "chmod <file> <permissions>: Change permissions of filesystem item\n"
        "logout: Logout of the current user\n"
        "exit: Exit the SFS"
    )


def shorten_path(path: str, permission=False):
    """
    Shortens the given path by replacing the main directory with a tilde (~) symbol.
    Optionally, if permission is set to True, it decrypts each directory name in the path.

    Args:
        path (str): The path to be shortened.
        permission (bool, optional): Whether to decrypt directory names. Defaults to False.

    Returns:
        str: The shortened path.

    """
    path = path.replace(MAIN_DIRECTORY, "~")
    temp = path.split(os.sep)
    if permission:
        for i in range(len(temp)):
            try:
                temp[i] = decrypt(temp[i])
            except:
                pass

    return os.sep.join(temp)


def check_permission(item: FileSystemItem, user: User, action: str) -> bool:
    """
    Check if a user has permission to perform an action on an item in the SFS.
    The admin user always has permission for all actions on all items.

    Parameters:
        item (FileSystemItem): The File or Directory object being accessed
        user (User): The user attempting to access the item
        action (str): One of either "r" (read) or "w" (write)

    Returns:
        bool: True if the user has permission for the action, otherwise False
    """
    if isinstance(user, Admin):
        return True
    if user.get_name() == item.get_owner():
        return item.get_access("user", action)
    elif user.get_group_name() == item.get_group():
        return item.get_access("group", action)
    else:
        return item.get_access("other", action)


def print_division(string: str):
    """
    Prints a division line with the given string in the center.

    Parameters:
    string (str): The string to be displayed in the center of the division line.
    """
    print("\n{:-^50}".format(" " + string + " "))


def createUser(username, password, group_name):
    """
    Creates a new user with the given username, password, and group name. Only the admin can create a new user.

    Parameters:
    - username (str): The username of the new user.
    - password (str): The password of the new user.
    - group_name (str): The group name of the new user.

    Returns:
    - None
    """
    if isinstance(current_user, Admin):  # only admin can create user
        for user in users:
            if user.get_name() == username:
                print("User Already Exists")
                return
        user = current_user.create_user(username, password, group_name)
        mkdir(abs_current_dir, user, username + "_Directory")
    else:
        print("Permission denied. Only the admin can create a new user.")


def createGroup(groupname):
    """
    Creates a new group with the given groupname. Only the admin can create a new group.

    Parameters:
    - groupname (str): The name of the new group.

    Returns:
    - None
    """
    if isinstance(current_user, Admin):  # only admin can create group
        current_user.create_group(groupname)
    else:
        print("Permission denied. Only the admin can create a new group.")


def pwd():
    """
    Returns the current working directory path.

    This function retrieves the absolute path of the current working directory
    and shortens it based on the user's permissions if they can see it or not.

    Returns:
        str: The shortened path of the current working directory.
    """
    if abs_current_dir != os.path.join(MAIN_DIRECTORY, "SFS"):
        current_dir = get_filesystem_item(abs_current_dir.split(os.sep)[-1])
        permission = check_permission(current_dir, current_user, "r")
    else:
        permission = True
    return shorten_path(abs_current_dir, permission)


def ls(long: bool):
    """
    Lists the contents of the current directory.

    Returns:
        str: A string containing the names of the directories and files in the current directory.
    """
    output = ""
    for item in os.listdir():
        item_name = item
        fs_item = get_filesystem_item(item)
        if check_permission(fs_item, current_user, "r"):
            item_name = decrypt(item)
        if long:
            output += f"{fs_item.get_permissions()} "
            output += f"{fs_item.get_owner()} "
            output += f"{fs_item.get_group()} "
        if os.path.isdir(item):
            output += f"{item_name} (directory)\n"
        else:
            output += f"{item_name} (file)\n"

    return output


def cd(dir_name):
    """
    Change the current directory to the specified directory.

    Args:
        dir (str): The directory to change to.

    Returns:
        None
    """
    global abs_current_dir
    if dir_name == "..":
        if abs_current_dir != os.path.join(MAIN_DIRECTORY, "SFS"):
            os.chdir(os.path.join(abs_current_dir, ".."))
            abs_current_dir = os.getcwd()
        else:
            print("Cannot go back further")
        return

    dir_name = encrypt(dir_name)
    directory = get_filesystem_item(dir_name)
    if os.path.exists(os.path.join(abs_current_dir, dir_name)):
        if check_permission(directory, current_user, "r"):
            abs_current_dir = os.path.join(abs_current_dir, dir_name)
            os.chdir(abs_current_dir)
        else:
            print("Permission denied to access the directory")
    else:
        print("Directory does not exist")


def cat(file_name: str):
    """
    Reads and prints the contents of a file if the user has permission.

    Args:
        file_name (str): The name of the file to read.

    Returns:
        None
    """
    file_name = encrypt(file_name)
    if not os.path.exists(file_name):
        print("Path does not exist")
        return

    fs_item = get_filesystem_item(file_name)
    if check_permission(fs_item, current_user, "r"):
        with open(file_name, "r") as file:
            file_content = file.read()
            if file_content == "":
                print("File is empty")
            else:
                try:
                    print(decrypt(file_content))
                except:
                    print("Error reading file")
    else:
        print("Permission denied to access the file")


def echo(file_name: str):
    """
    Writes user input to a file if the user has permission.

    Args:
        file_name (str): The name of the file to write to.

    Returns:
        None
    """
    file_name = encrypt(file_name)
    if not os.path.exists(file_name):
        print("Path does not exist")
        return

    fs_item = get_filesystem_item(file_name)
    if check_permission(fs_item, current_user, "w"):
        text_input = input_encrypted("Enter text to write to file: ")
        with open(file_name, "w") as file:
            file.write(text_input)
            fs_item.add_content(text_input)
            store_files()
    else:
        print("Permission denied to access the file")


def mkdir(dir_name: str, user: User, new_dir: str):
    """
    Create a new directory in the specified directory.

    Args:
        dir_name (str): The path of the directory in which the new directory will be created.
        user (User): The user object representing the user owning the directory
        new_dir (str): The name of the new directory to be created.

    Returns:
        None
    """

    new_dir_encrypted = encrypt(new_dir)

    if os.path.exists(new_dir_encrypted):
        print("Directory already exists")
        return

    if dir_name == os.path.join(MAIN_DIRECTORY, "SFS"):
        if not isinstance(current_user, Admin):
            print("Can't create directories in the SFS folder as a non-admin user")
            return

    directory = get_filesystem_item(dir_name.split(os.sep)[-1])
    # Need write permission to current directory to create directories
    if check_permission(directory, current_user, "w"):
        new_directory = os.path.join(dir_name, new_dir_encrypted)
        if not os.path.exists(new_directory):
            os.mkdir(new_directory)
            directory = Directory(
                new_dir_encrypted, user.get_name(), user.get_group_name()
            )
            if os.path.join(MAIN_DIRECTORY, "SFS") == dir_name:
                store_filesystem(directory)
            else:
                print(os.path.dirname(dir_name) + os.sep, "")
                store_filesystem(directory, dir_name)
    else:
        print("Permission denied")


def touch(file_name: str):
    """
    Creates a new file with the given file name in the Secure File System (SFS).

    Args:
        file_name (str): The name of the file to be created.

    Returns:
        None
    """
    global current_user
    file_name = encrypt(file_name)
    if os.path.exists(file_name):
        print("File already exists")
        return  # File already exists

    if abs_current_dir == os.path.join(MAIN_DIRECTORY, "SFS"):
        if isinstance(current_user, Admin):
            with open(file_name, "w") as __:
                new_file = File(
                    file_name, current_user.get_name(), current_user.get_group_name()
                )
                store_filesystem(new_file)
                return  # Admin can create files in the SFS folder
        else:
            print("Can't create files in the SFS folder as a non-admin user")
            return  # Non-admin users can't create files in the SFS folder

    # Get current directory
    dir_name = abs_current_dir.split(os.sep)[-1]
    directory = get_filesystem_item(dir_name)
    # Need write permission to current directory to create files
    if check_permission(directory, current_user, "w"):
        with open(file_name, "w") as __:
            new_file = File(
                file_name,
                current_user.get_name(),
                current_user.get_group_name(),
            )
            store_filesystem(new_file, dir_name)
        return  # File created successfully
    else:
        print("Permission denied to create a file in the directory")
        return  # Permission denied


def mv(old_filename: str, new_name: str):
    """
    Renames a file in the file system.

    Args:
        old_filename (str): The name of the file to be renamed.
        new_name (str): The new name for the file.

    Returns:
        None
    """
    old_filename = encrypt(old_filename)

    if not os.path.exists(old_filename):
        print("Path does not exist")
        return

    new_name = encrypt(new_name)
    file = get_filesystem_item(old_filename)
    if check_permission(file, current_user, "w"):
        os.rename(old_filename, new_name)
        file.set_name(new_name)
        store_files()
    else:
        print("Permission denied to rename the file")


def rm(file_name: str):
    """
    Remove a file from the file system and the database if the user has the permission to do so and the file exists.
    :param file_name: The name of the file to remove
    """
    file_name = encrypt(file_name)
    file = get_filesystem_item(file_name)
    if check_permission(file, current_user, "w"):
        if os.path.exists(file_name):
            os.remove(file_name)
            for index in range(0, len(fs_items)):
                if fs_items[index].get_name() == file_name:
                    fs_items.pop(index)
                    break

            for index in range(0, len(fs_items)):
                if isinstance(fs_items[index], Directory):
                    contents = fs_items[index].get_contents()
                    for j in range(len(contents)):
                        if contents[j].get_name() == file_name:
                            contents.remove(contents[j])
                            fs_items[index].set_contents(contents)
                            break

            store_files()

        else:
            print("Path does not exist")
    else:
        print("Permission denied")


def chmod(fs_itemname: str, mode: str):
    if re.match(r"^[rw-]{6}$", mode) is None:
        print("Invalid mode")
    else:
        f = get_filesystem_item(encrypt(fs_itemname))
        if isinstance(current_user, Admin) or f.get_owner() == current_user.get_name():
            f.set_permissions(mode)
        else:
            print("Permission denied")


def process_cmd(command: str):
    """
    Process the given command and perform the corresponding action.

    Args:
        command (str): The command to be processed.

    Returns:
        bool: True if the command is "logout", False otherwise.
    """
    global current_user
    argv = command.split(" ")
    if argv[0] == "help":
        print_help()
    elif argv[0] == "pwd":
        print(pwd())
    elif argv[0] == "ls":
        print("List of files and directories:")
        long = False
        if len(argv) == 2 and argv[1] == "-l":
            long = True
        print(ls(long))
    elif argv[0] == "cd":
        if len(argv) == 2 and argv[1] != "":
            cd(argv[1])
        else:
            print("Invalid Number of arguments")
    elif argv[0] == "mkdir":
        if len(argv) == 2:
            mkdir(abs_current_dir, current_user, new_dir=argv[1])
            store_files()
        else:
            print("Invalid Number of arguments")
    elif argv[0] == "touch":
        if len(argv) == 2:
            touch(argv[1])
        else:
            print("Invalid Number of arguments")
    elif argv[0] == "createuser":
        if len(argv) == 4:
            createUser(argv[1], argv[2], argv[3])
        else:
            print("Invalid Number of arguments")
    elif argv[0] == "creategroup":
        if len(argv) == 2:
            createGroup(argv[1])
        else:
            print("Invalid Number of arguments")
    elif argv[0] == "cat":
        if len(argv) == 2:
            cat(argv[1])
        else:
            print("Invalid Number of arguments")
    elif argv[0] == "echo":
        if len(argv) == 2:
            echo(argv[1])
        else:
            print("Invalid Number of arguments")
    elif argv[0] == "mv":
        if len(argv) == 3:
            mv(argv[1], argv[2])
        else:
            print("Invalid Number of arguments")
    elif argv[0] == "rm":
        if len(argv) == 2:
            rm(argv[1])
        else:
            print("Invalid Number of arguments")
    elif argv[0] == "chmod":
        if len(argv) == 3:
            chmod(argv[1], argv[2])
        else:
            print("Invalid Number of arguments")
    elif argv[0] == "logout":
        return True
    elif argv[0] == "exit":
        exit()
    elif argv[0] == "store":
        store_files()
    else:
        print("Invalid Command")

    return False


# user login interface
def login():
    """
    Prompts the user to enter their username and password to log into the SFS.
    If the username and password match with what is stored in the database,
    the user is logged in successfully.
    """

    while True:
        print_division("SIGN IN")
        user_name = input("Please enter your username: ")
        # get encrypted password sent by user
        pwd_enc = input_encrypted("Please enter your password: ")
        # decrypt password
        password = decrypt(pwd_enc)

        # check if the username and password match with what stored in database
        global current_user
        user = get_user(user_name)
        if verify_password(user, password):
            # logged into the SFS
            current_user = user
            integrity_check()
            store_database()
            os.chdir(abs_current_dir)
            break


def sfs():
    """
    Main function for the Secure File System (SFS).

    This function handles the user interaction with the SFS. It prompts the user for encrypted commands,
    decrypts them, and processes the commands accordingly. It also performs permission verification.

    Returns:
        bool: True if the user chooses to logout, False otherwise.
    """
    global current_user, abs_current_dir

    while True:
        # get encrypted command
        prompt = pwd() + " >> "
        cmd_enc = input_encrypted(prompt)
        cmd = decrypt(cmd_enc)
        logout = process_cmd(cmd)
        if logout:
            abs_current_dir = os.path.join(MAIN_DIRECTORY, "SFS")
            return


def main():
    """
    The main function of the SFS program.

    This function sets up the server, creates the main server directory if it doesn't exist,
    loads the database, and starts the login and SFS processes.
    """

    # setup server
    # Create the main server Directory if it doesn't exist
    if not os.path.exists(abs_current_dir) or not os.path.isdir(abs_current_dir):
        os.mkdir(abs_current_dir)
    load_database()
    print_division("WELCOME")
    os.chdir(abs_current_dir)  # Change directory to the SFS folder
    while True:
        login()
        sfs()


def input_encrypted(prompt: str) -> str:
    """
    Encrypts user input and returns the encrypted string.

    Args:
        prompt (str): The prompt to display to the user.

    Returns:
        str: The encrypted user input.
    """

    return encrypt(input(prompt))


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print()
        print_division("Exit")

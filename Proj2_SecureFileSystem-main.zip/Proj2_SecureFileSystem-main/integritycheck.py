import os
from database import (
    MAIN_DIRECTORY,
)
from file_system_item import (
    convert_hash,
)

from encryption import decrypt


class integrityDirectory:
    """
    Represents a directory with integrity information obtained from the database file.
    Attributes:
        name (str): The name of the directory.
        owner (str): The owner of the directory.
        group (str): The group of the directory.
        hash (str): The hash value of the directory.
    """

    def __init__(self, name, owner, group, hash):
        self.name = name
        self.owner = owner
        self.group = group
        self.hash = hash


class integrityFile:
    """
    Represents a file with integrity information obtained from the database file.
    Attributes:
        name (str): The name of the file.
        owner (str): The owner of the file.
        group (str): The group of the file.
        hash (str): The hash value of the file.
    """

    def __init__(self, name, owner, group, hash):
        self.name = name
        self.owner = owner
        self.group = group
        self.hash = hash


def get_parent_directory(directory, file_name) -> str:
    """
    Recursively searches for the parent directory that contains the specified file.
    Args:
        directory (str): The directory to start the search from.
        file_name (str): The name of the file to search for.
    Returns:
        str: The path of the parent directory that contains the file, or None if the file is not found.
    """
    os.chdir(directory)
    if file_name in os.listdir():
        os.chdir("..")
        return directory

    for item in os.listdir():
        if os.path.isdir(item):
            parent_dir = get_parent_directory(os.path.join(directory, item), file_name)
            if parent_dir:
                return parent_dir
            os.chdir("..")

    return None


def get_file_content(directory, file_name) -> str | None:
    """
    Recursively searches for the file in the specified directory and its subdirectories.
    Args:
        directory (str): The directory to search in.
        file_name (str): The name of the file to search for.
    Returns:
        str | None: The content of the file if found, or None if the file is not found.
    """
    os.chdir(directory)

    if file_name in os.listdir() and os.path.isfile(file_name):
        with open(file_name, "r") as file:
            file_content = file.read()
            return file_content

    for item in os.listdir():
        if os.path.isdir(item):
            os.chdir(item)
            file_content = get_file_content(os.getcwd(), file_name)
            if file_content:
                return file_content
            os.chdir("..")

    return None


def integrity_check_file(integrity_file_systems_list, item_name):
    """
    Check the integrity of a file by comparing its hash with the hash stored in the integrity_file_systems_list.
    Parameters:
    integrity_file_systems_list (list): A list of files in the integrity file system.
    item_name (str): The name of the file to be checked.
    Returns:
    str or None: The calculated hash of the file if it is found in the integrity_file_systems_list and the integrity check passes. None if the file is not found.
    """
    item_found = False
    with open(item_name, "r") as file:
        file_content = file.read()
        if file_content == "":
            file_content = ""
    file_hash = convert_hash(item_name + file_content)
    for file in integrity_file_systems_list:
        if file.name == item_name:
            item_found = True
            if file.hash != file_hash:
                print("Integrity check failed")
                print("File: ", item_name)
                print(
                    "Hash in Database: ",
                    file.hash,
                    "      !=      ",
                    file_hash,
                    "Calculated Hash",
                )

            return file_hash

    if not item_found:
        print("File Not Found, FAILED INTEGRITY CHECK")
        print("File: ", (item_name))
        return None


def integrity_check_directory(integrity_file_systems_list, directory_name):
    """
    Check the integrity of a directory by comparing its hash with the hash stored in the integrity_file_systems_list.
    Parameters:
    integrity_file_systems_list (list): A list of files in the integrity file system.
    directory_name (str): The name of the directory to be checked.
    Returns:
    str or None: The calculated hash of the directory if it is found in the integrity_file_systems_list and the integrity check passes. None if the directory is not found.
    """
    file_system_hash = directory_name
    directory_found = False

    list_of_files = os.listdir()
    for item in list_of_files:
        if os.path.isdir(item):
            os.chdir(item)
            directory_hash = integrity_check_directory(
                integrity_file_systems_list, item
            )
            if directory_hash is not None:
                file_system_hash += directory_hash
            os.chdir("..")
        else:
            file_hash = integrity_check_file(integrity_file_systems_list, item)
            if file_hash is not None:
                file_system_hash += file_hash

    directory_hash = convert_hash(file_system_hash)

    for file_item in integrity_file_systems_list:
        if (
            isinstance(file_item, integrityDirectory)
            and file_item.name == directory_name
        ):
            directory_found = True
            if directory_hash:
                if file_item.hash != directory_hash:
                    print("Integrity check failed")
                    print("Directory: ", directory_name)
                    print(
                        "Hash in Database: ",
                        file_item.hash,
                        "      !=      ",
                        directory_hash,
                        "Calculated Hash",
                    )
                    pass
                return directory_hash
            break

    if not directory_found:
        print("Directory Not Found, FAILED INTEGRITY CHECK")
        print("Directory: ", (directory_name))
        return None


def load_integrity_file_systems():
    """
    Load the integrity information of directories and files from the database file.
    Returns:
    list: A list of integrityFile and integrityDirectory objects.
    """
    integrity_file_systems_list = []
    file_name = os.path.join(MAIN_DIRECTORY, "filesystemdb.txt")
    with open(file_name, "r") as file:
        for line in file:
            try:
                line = decrypt(line)
            except:
                print("ERROR DECRYPTING FILESYSTEMDB")
                continue
            parts = line.strip().split(",")

            if len(parts) < 5:
                print("ERROR IN THE DATABASE FILE")
                continue

            if parts[0] == "d":
                integrity_file_systems_list.append(
                    integrityDirectory(parts[1], parts[2], parts[3], parts[4])
                )
            else:
                integrity_file_systems_list.append(
                    integrityFile(parts[1], parts[2], parts[3], parts[4])
                )

    return integrity_file_systems_list


def integrity_check():
    """
    Loads all the directories and files inside the current directory, calculates their hashes,
    and compares them with the values from the database file_systems[].
    Returns:
        None
    """
    integrity_file_systems_list = load_integrity_file_systems()
    for item_name in os.listdir():
        if os.path.isdir(item_name):
            os.chdir(item_name)
            integrity_check_directory(integrity_file_systems_list, item_name)
            os.chdir("..")
        else:
            integrity_check_file(integrity_file_systems_list, item_name)

from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import base64

key = b"r\x04\x85\xb2\xf2\x84\xce\x1e\xd4\x88b\xa4w\xa6ia"  # key for encryption and decryption


def encrypt(message: str) -> str:
    """
    Encrypts a given message using AES encryption.
    Args:
        message (str): The message to be encrypted.
    Returns:
        str: The encrypted ciphertext.
    """
    cipher = AES.new(key, AES.MODE_ECB)
    ct_bytes = cipher.encrypt(pad(message.encode(), AES.block_size))
    ciphertext = base64.urlsafe_b64encode(ct_bytes).decode("utf-8")
    return ciphertext


def decrypt(ct: str) -> str:
    """
    Decrypts a given ciphertext using AES encryption.
    Args:
        ct (str): The ciphertext to be decrypted.
    Returns:
        str: The decrypted message.
    """
    ct = base64.urlsafe_b64decode(ct)
    cipher = AES.new(key, AES.MODE_ECB)
    pt = unpad(cipher.decrypt(ct), AES.block_size)
    return pt.decode("utf-8")

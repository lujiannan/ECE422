from user import User, Group, Admin
from file_system_item import FileSystemItem, Directory, File, FS_ItemMode
import bcrypt  # hash password
import os
from encryption import encrypt, decrypt

MAIN_DIRECTORY = os.getcwd()  # NEVER CHANGES
USERDB = os.path.join(MAIN_DIRECTORY, "userdb.txt")
GROUPDB = os.path.join(MAIN_DIRECTORY, "groupdb.txt")
FILESYSTEMDB = os.path.join(MAIN_DIRECTORY, "filesystemdb.txt")
groups: list[Group] = []
users: list[User] = []
fs_items: list[FileSystemItem] = []


# Check if the provided password matches the hashed password
def verify_password(user: User, password: str) -> bool:
    """
    Verify the provided password against the hashed password stored in the user object.
    Args:
        user (User): The user object containing the hashed password.
        password (str): The password to be verified.
    Returns:
        bool: True if the password matches the hashed password, False otherwise.
    """
    saved_pass_hash = user.get_password().encode("utf-8")
    return bcrypt.checkpw(password.encode("utf-8"), saved_pass_hash)


def get_user(username: str) -> User:
    """
    Get the user object with the provided username.
    Args:
        username (str): The username of the user to be retrieved.
    Returns:
        User: The user object with the provided username, or None if the user does not exist.
    """
    for user in users:
        if user.get_name() == username:
            return user
    return None


def add_group_member(group_name: str, user_name: str):
    """
    Adds a member to a group.
    Parameters:
    - group_name (str): The name of the group.
    - user_name (str): The name of the user to be added.
    Returns:
    - None
    """
    for i in range(len(groups)):
        if groups[i].get_group_name() == group_name:
            if user_name in groups[i].get_members():
                return

            groups[i].add_member(user_name)
            break

    store_groups()


def get_group(group_name: str) -> Group:
    """
    Get the group object with the provided group name.
    Args:
        group_name (str): The name of the group to be retrieved.
    Returns:
        Group: The group object with the provided group name, or None if the group does not exist.
    """
    for group in groups:
        if group.get_group_name() == group_name:
            return group
    return None


def get_filesystem_item(name: str) -> FileSystemItem:
    """
    Get the file system item with the provided name.
    Args:
        name (str): The name of the file system item to be retrieved.
    Returns:
        FileSystemItem: The file system item with the provided name, or None if the item does not exist.
    """
    for item in fs_items:
        if item.get_name() == name:
            return item
    return None


def load_groups():
    """
    Load groups from the GROUPDB file.

    This function reads the contents of the GROUPDB file, decrypts each line, and creates Group objects
    based on the parsed data. The created Group objects are then appended to the 'groups' list.

    Returns:
        None
    """
    groups.clear()
    with open(GROUPDB, "r") as file:
        for line in file:
            try:
                line = decrypt(line)
            except:
                print("ERROR DECRYPTING FILESYSTEMDB")
                continue
            parts = line.strip().split(",")
            group = Group(parts[0], parts[1:])
            groups.append(group)


def load_users():
    """
    Load users from the USERDB file.
    This function reads the contents of the USERDB file, decrypts each line, and creates User objects
    based on the parsed data. The created User objects are then appended to the 'users' list.
    Returns:
        None
    """
    users.clear()
    with open(USERDB, "r") as file:
        for line in file:
            try:
                line = decrypt(line)
            except:
                print("ERROR DECRYPTING FILESYSTEMDB")
                continue
            parts = line.strip().split(",")
            if parts[0] == "admin":
                user = Admin()
            else:
                user = User(parts[0], parts[1], parts[2])
            users.append(user)


def load_file_system():
    """
    Load the file system from the FILESYSTEMDB file.
    This function reads the contents of the FILESYSTEMDB file, decrypts each line, and creates FileSystemItem objects
    based on the parsed data. The created FileSystemItem objects are then appended to the 'fs_items' list.
    Returns:
        None
    """
    from integritycheck import get_file_content, get_parent_directory

    fs_items.clear()
    with open(FILESYSTEMDB, "r") as file:
        for line in file:
            try:
                line = decrypt(line)
            except:
                print("ERROR DECRYPTING FILESYSTEMDB")
                continue
            parts = line.strip().split(",")
            new_file = None

            if len(parts) < 5:
                print("ERROR IN THE DATABASE FILE")
                continue

            if parts[0] == "d":
                new_file = Directory(parts[1], parts[2], parts[3], permission=FS_ItemMode(parts[5]))
            else:
                file_content = get_file_content(
                    os.path.join(MAIN_DIRECTORY, "SFS"), parts[1]
                )
                new_file = File(
                    parts[1],
                    parts[2],
                    parts[3],
                    file_content if (file_content is not None) else "",
                    FS_ItemMode(parts[5]),
                )

            fs_items.append(new_file)

    array = {}
    for item in fs_items:
        dir = get_parent_directory(os.path.join(MAIN_DIRECTORY, "SFS"), item.get_name())

        if dir is None:
            continue

        dir = dir.split(os.sep)[-1]
        if dir != "SFS":
            if dir in array:
                array[dir].append(item)
            else:
                array[dir] = [item]

    for key in array:
        index = -1
        for i in range(len(fs_items)):
            if fs_items[i].get_name() == key:
                index = i
        if index != -1:
            fs_items[index].set_contents(array[key])


def load_database():
    """
    Load the database files.
    This function loads the GROUPDB, USERDB, and FILESYSTEMDB files. It creates the files if they do not exist,
    then loads the data from the files into the 'groups', 'users', and 'fs_items' lists.
    Returns:
        None
    """
    # create the text files if it doesn't exist
    fresh_start = False
    if not os.path.exists(GROUPDB):
        with open(GROUPDB, "w") as __:
            pass
    if not os.path.exists(USERDB):
        with open(USERDB, "w") as __:
            pass
        fresh_start = True

    if not os.path.exists(FILESYSTEMDB):
        with open(FILESYSTEMDB, "w") as __:
            pass

    load_groups()
    load_users()
    load_file_system()

    if fresh_start:
        # Create the admin user
        admin = Admin()
        store_user(admin)


def store_database():
    """
    Store the groups, users, and file system items into the respective database files.
    This function stores the groups, users, and file system items into the GROUPDB, USERDB, and FILESYSTEMDB files.
    Returns:
        None
    """
    store_groups()
    store_users()
    store_files()


# store / update group data into database
def store_group(group: Group):
    """
    Stores a group in the database.
    If the group already exists in the database, it will be updated with the provided group.
    If the group does not exist, it will be added to the database.

    Args:
        group (Group): The group object to store in the database.
    Returns:
        None
    """
    if get_group(group.get_group_name()):
        # Update the group
        for i in range(len(groups)):
            if groups[i].get_group_name() == group.get_group_name():
                groups[i] = group  # update the group
    else:
        # Add the group
        groups.append(group)

    store_groups()


def store_user(user: User):
    """
    Stores a user in the database.
    If the user already exists in the database, it will be updated with the provided user.
    If the user does not exist, it will be added to the database.
    Args:
        user (User): The user object to store in the database.
    Returns:
        None
    """
    user_found = False
    for i in range(len(users)):
        if users[i].get_name() == user.get_name():
            users[i] = user
            user_found = True
            break

    if not user_found:
        # Add the user
        users.append(user)

    store_users()

    # Add the user to the group
    add_group_member(user.get_group_name(), user.get_name())


def store_filesystem(item: FileSystemItem, parent_dir: str = None):
    """
    Stores a file system item in the database.
    If the item already exists in the database, it will be updated with the provided item.
    If the item does not exist, it will be added to the database.
    Args:
        item (FileSystemItem): The file system item to store in the database.
        parent_dir (str): The name of the parent directory to store the item in.
    Returns:
        None
    """
    if get_filesystem_item(item.get_name()):
        # Update the file system
        for i in range(len(fs_items)):
            if fs_items[i].get_name() == item.get_name():
                fs_items[i] = item  # update the group
    else:
        # Add the file system
        fs_items.append(item)

    if parent_dir is not None:
        for i in range(len(fs_items)):
            if fs_items[i].get_name() == parent_dir:
                if isinstance(fs_items[i], Directory):
                    if isinstance(item, File):
                        fs_items[i].create_file(item)
                    else:
                        fs_items[i].create_dir(item)
                    break

    store_files()


def store_files():
    """
    Stores the files in the filesystem database.
    This function opens the filesystem database file in write mode and writes the encrypted string representation
    of each file item in the `fs_items` list, separated by newlines.
    Parameters:
        None
    Returns:
        None
    """
    with open(FILESYSTEMDB, "w") as file:
        for item in fs_items:
            file.write(encrypt(item.get_database_str()) + "\n")


def store_groups():
    """
    Stores the groups in the group database.
    This function opens the group database file in write mode and writes the encrypted string representation
    of each group in the `groups` list, separated by newlines.
    Parameters:
        None
    Returns:
        None
    """
    with open(GROUPDB, "w") as file:
        for group in groups:
            file.write(encrypt(group.get_database_str()) + "\n")


def store_users():
    """
    Stores the users in the user database.
    This function opens the user database file in write mode and writes the encrypted string representation
    of each user in the `users` list, separated by newlines.
    Parameters:
        None
    Returns:
        None
    """
    with open(USERDB, "w") as file:
        for user in users:
            file.write(encrypt(user.get_database_str()) + "\n")

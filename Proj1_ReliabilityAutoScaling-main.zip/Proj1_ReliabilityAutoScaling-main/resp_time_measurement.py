#!/usr/bin/env python

from bcc import BPF
from redis import StrictRedis, exceptions

redis = StrictRedis(host='localhost', port=6379, decode_responses=True)


def handle_event(cpu, data, size):
    response_time = b["client_session_events"].event(data)
    redis.rpush("response_times", response_time.response_time_us/1000000.0)
    print("time", response_time.response_time_us/1000000.0)


b = BPF(src_file="resp_time_bcc.c")
b["client_session_events"].open_perf_buffer(handle_event)
print("started bcc")

while True:
    try:
        b.perf_buffer_poll()
    except KeyboardInterrupt:
        exit()

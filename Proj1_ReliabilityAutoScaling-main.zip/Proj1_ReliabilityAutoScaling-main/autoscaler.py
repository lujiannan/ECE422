import docker
import time
from redis import StrictRedis, exceptions
import matplotlib.pyplot as plt

service_name = "app_name_web"

client = docker.from_env()

lowerBoundInS = 4  # the lower bound of our interval
upperBoundInS = 8  # the upper bound of our interval

numScaleOut = 10  # the default number of containers when scaling out
numScaleIn = 3  # the default number of containers when scaling in

application_size_data = []  # Used for plotting the application size graph


# Returns the average response time by taking the average of the response times in a Redis database.
def getAvgTime():
    sum_time = 0.00
    num_time = 0.00
    avg_time = 0.00

    redis = StrictRedis(host="localhost", port=6379, decode_responses=True)

    try:
        # retrieve all elements from response_times list
        list_len = redis.llen("response_times")
        times_string = redis.lpop("response_times", list_len)
    except KeyboardInterrupt:
        print("\nKeyboardInterrupt")
    except exceptions.RedisError:
        print("Response times in the node is not available in database")
        return None
    except Exception as e:
        print(e)
        return None

    if times_string != None:
        times_float = [float(time) for time in times_string]
        sum_time += sum(times_float)
        num_time += len(times_float)

    if num_time > 0:
        avg_time = sum_time / num_time
    print("The average response time among 10 seconds is {}s".format(avg_time))
    return avg_time


# Scales the number of containers depending on the average response time
def scaleApp(responseTime):
    service = client.services.get(service_name)

    current_size = service.attrs["Spec"]["Mode"]["Replicated"]["Replicas"]
    new_size = current_size

    if responseTime < lowerBoundInS:
        if current_size <= numScaleIn:
            new_size = round(current_size / 1.5)
        else:
            new_size = numScaleIn
    elif responseTime > upperBoundInS:
        if current_size >= numScaleOut:
            new_size = min(
                round(current_size * 1.5), 20
            )  # the max number of replicas for our docker is 20,
        else:
            new_size = numScaleOut

    if new_size != current_size:
        updated_mode = {"Replicated": {"Replicas": new_size}}
        service.update(mode=updated_mode)
        current_size = new_size
        print("Scaled")

    return current_size


# plot the application size data vs time
def plot_data():
    plt.figure(figsize=(15, 5))

    plt.plot(application_size_data, color="red")
    plt.title("Application Size")
    plt.xlabel("Time in 10 seconds")
    plt.ylabel("Application Size")

    plt.savefig("application_size.png")


def main():
    sleepTime = 10
    while True:
        time.sleep(sleepTime)
        avgTime = getAvgTime()
        current_size = scaleApp(avgTime)
        application_size_data.append(current_size)

        plot_data()


if __name__ == "__main__":
    main()

// Needed for this to compile on the version of bcc on the VMs
#define KBUILD_MODNAME "placeholder"

#include <linux/tcp.h>
#include <net/sock.h>

// Struct for passing event data to python callback
struct response_time_event {
	u64 response_time_us;
};

// output buffer for events
BPF_PERF_OUTPUT(client_session_events);

// Hashmap of outstanding connections
BPF_HASH(pending_requests, struct sock *, u64);

// Hook into network socket events
TRACEPOINT_PROBE(sock, inet_sock_set_state)
{
	// Ignore all events not related to the web server
	if (args->sport != 8000)
		return 0;
	if (args->protocol != IPPROTO_TCP)
		return 0;

	struct sock *socket_addr = (struct sock *)args->skaddr;
	u64 response_time_us, start_time_us, end_time_us;
	u64 *timestamp_p;

	switch (args->newstate) {
	case TCP_ESTABLISHED: // Server established connection with client
		start_time_us = bpf_ktime_get_ns() / 1000;
		pending_requests.update(&socket_addr, &start_time_us);
		break;
	case TCP_CLOSE: // Server finished servicing request
		end_time_us = bpf_ktime_get_ns() / 1000;	
		timestamp_p = (u64 *)pending_requests.lookup(&socket_addr);
		if (timestamp_p != NULL) {
			pending_requests.delete(&socket_addr);
			start_time_us = *timestamp_p;
			response_time_us = end_time_us - start_time_us;
			struct response_time_event event;
			event.response_time_us = response_time_us;
			client_session_events.perf_submit(args, &event, sizeof(event));
		}
		break;
	default:
		return 0;
	}

	return 0;
}
